﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KBezminovS
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        Menu menu = new Menu();
        Menu2_Manager menu2_manager = new Menu2_Manager();
        Menu3_Seller menu3_seller = new Menu3_Seller();

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            {
                try
                {
                    using (var context = new TradingCompanyEntities())
                    {
                        var login = LogTextBox.Text;
                        var password = PasswordTextBox.Password;
                        var user = context.Account.FirstOrDefault(u => u.Login == login && u.Password == password);

                        if (user != null)
                        {
                            if (user.Role == "Администратор")
                            {
                                MainWindow mainWindow = new MainWindow();
                                mainWindow.menu.Show();
                                Close();
                            }
                            else if (user.Role == "Менеджер")
                            {
                                MainWindow mainWindow = new MainWindow();
                                mainWindow.menu2_manager.Show();
                                Close();
                            }
                            else if (user.Role == "Продавец")
                            {
                                MainWindow mainWindow = new MainWindow();
                                mainWindow.menu3_seller.Show();
                                Close();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Роль пользователя не найдена.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Произошла ошибка при подключении к базе данных: " + ex.Message);
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ExitDialog exitdialog = new ExitDialog();
            exitdialog.Show();
        }
    }
}
